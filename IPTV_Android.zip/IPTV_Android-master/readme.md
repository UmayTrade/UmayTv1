### IPTV APP FOR ANDROID DEVICES (TV AND MOBILE)

##### YouTube Tutorial: Coming soon 

##### This app has the following features 

1. Exo player implementation
2. Hls Streaming, .m3u8
3. Recyclerview items have focus 


#### APP LAYOUT 

![](images/first.jpg)
![](images/second.jpg)


##### Disclaimer: 
Streaming links are available at https://github.com/iptv-org/iptv
