package com.example.mytvapp.modal

data class Channel(

    val channelName: String,
    val channelIcon: Int,
    val channelLink: String,




    ){
}